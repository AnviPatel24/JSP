package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class takeorder extends AppCompatActivity {
    EditText txtphone,txtitem,txtquan;
    Button btnsave;
    long execute;
    DatabaseHelper5 dbh5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_takeorder);
        dbh5=new DatabaseHelper5(takeorder.this,"dbpr3",null,1);
        ControlInitialization();
        ButtonClick();

    }

    public void ButtonClick() {
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String phone=txtphone.getText().toString();
                String item=txtitem.getText().toString();
                String quan=txtquan.getText().toString();
                execute=dbh5.additem(phone,item,quan);
                if(execute!=0)
                {
                    Toast.makeText(takeorder.this, "Item Inserted Successfully", Toast.LENGTH_SHORT).show();
                    Intent objIntent=new Intent(getApplicationContext(),pr5.class);
                    startActivity(objIntent);
                }
            }
        });
    }

    public void ControlInitialization(){
        txtphone=findViewById(R.id.etphone);
        txtitem=findViewById(R.id.etitem);
        txtquan=findViewById(R.id.etquantity);
        btnsave=findViewById(R.id.btnsaveo);
    }
}
package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class pr5 extends AppCompatActivity {

    Button btake,btview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pr5);
        btake=findViewById(R.id.btntakeo);
        btview=findViewById(R.id.btnviewo);
        ButtonClick();
    }

    private void ButtonClick() {
        btake.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objintent=new Intent(getApplicationContext(),takeorder.class);
                startActivity(objintent);
            }
        });

        btview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objintent=new Intent(getApplicationContext(),showorder.class);
                startActivity(objintent);
            }
        });
    }
}
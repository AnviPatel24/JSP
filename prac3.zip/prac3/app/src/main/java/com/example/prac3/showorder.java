package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class showorder extends AppCompatActivity {
    DatabaseHelper5 dbh5;
    ListView lstitem;
    ArrayList<String> Listshow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showorder);
        dbh5=new DatabaseHelper5(showorder.this,"dbpr3",null,1);
        lstitem=findViewById(R.id.showorderitem);
        Listshow=new ArrayList<>();
        displaydata();
    }

    private void displaydata() {
        Cursor c= dbh5.display();
        if (c!=null) {
            Toast.makeText(this, "Cursor Is Not Null", Toast.LENGTH_SHORT).show();
            while(c.moveToNext()){
                Listshow.add("Customer Phone: "+c.getString(1)+"\nItem Name: "+c.getString(2)+"\nItem Quantity: "+c.getString(3));
            }
            ArrayAdapter adapter=new ArrayAdapter(this, android.R.layout.simple_list_item_1,Listshow);
            lstitem.setAdapter(adapter);
        }
        else{
            Toast.makeText(this, "Cursor Is Null", Toast.LENGTH_SHORT).show();
        }
    }
}
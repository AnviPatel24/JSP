package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class welcome extends AppCompatActivity {

        TextView txtview;
        String username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);
        ControlInitialization();
        txtview.setText("Welcome");
        if(!isLoggedIn()){
            Intent objIntent=new Intent(getApplicationContext(),pr1.class);
            startActivity(objIntent);
        }
        else{
            txtview.setText("Welcome"+username);
        }
    }

    public void ControlInitialization(){
        txtview=findViewById(R.id.txtwelcome);
    }
    public boolean isLoggedIn(){
        SharedPreferences sh=getSharedPreferences("Login",MODE_PRIVATE);
        username=sh.getString("username",null);
        password=sh.getString("password",null);
        return username!=null & password!=null;
    }
}
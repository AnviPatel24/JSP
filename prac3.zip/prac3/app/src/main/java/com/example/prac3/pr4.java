package com.example.prac3;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.util.ArrayList;

public class pr4 extends AppCompatActivity {

    String num;
    ListView listshow;
    ArrayList<String> list1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pr4);

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 123);

        listshow=findViewById(R.id.con);
        list1=new ArrayList<>();

        fetchcontact();


        listshow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String sms= list1.get(position);
                String[] pyor=sms.split("\n");

                String filter=pyor[1];

                Toast.makeText(pr4.this,filter, Toast.LENGTH_SHORT).show();


                try{

                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(filter,null,"Number: "+pyor[1],null,null);


                    Toast.makeText(getApplicationContext(), "Message Sent", Toast.LENGTH_SHORT).show();
                }catch (Exception e){
                    Toast.makeText(getApplicationContext(), "Error:" + e, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void fetchcontact(){


        Uri uri= ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection={ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER};
        String selection=null;
        String[] selectionArgs=null;
        String sortOrder=null;
        ContentResolver resolver=getContentResolver();
        Cursor c= resolver.query(uri,projection,selection,selectionArgs,sortOrder);

     if(c!=null){

         Toast.makeText(this, "c is not null", Toast.LENGTH_SHORT).show();
         while (c.moveToNext()){

             @SuppressLint("Range") String name=c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
             @SuppressLint("Range") String number=c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

             list1.add(name+"\n"+number);
             Log.d("hello",name+number);
         }



         ArrayAdapter<String> at=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,list1);
         listshow.setAdapter(at);

     }
     else{
         Toast.makeText(this, "c null", Toast.LENGTH_SHORT).show();
     }





    }
}
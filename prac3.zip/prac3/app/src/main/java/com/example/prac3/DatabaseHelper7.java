package com.example.prac3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.nio.charset.StandardCharsets;

public class DatabaseHelper7 extends SQLiteOpenHelper {
    public DatabaseHelper7( Context context, String dbname,SQLiteDatabase.CursorFactory factory, int version) {
        super(context, dbname, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(" CREATE TABLE STUDENT(sid INTEGER PRIMARY KEY AUTOINCREMENT,stname varchar(50),stage varchar(20),ststream varchar(12),stpass varchar(10),stper varchar(10))");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS STUDENT");
        onCreate(db);
    }


    public long addstudent(String name,String age,String stream,String year,String percent){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("stname",name);
        cv.put("stage",age);
        cv.put("ststream",stream);
        cv.put("stpass",year);
        cv.put("stper",percent);
        long in=db.insert("STUDENT",null,cv);
        return in;
    }

    public Cursor displaystud(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c=db.rawQuery("SELECT * FROM STUDENT",null);
        return c;
    }
}

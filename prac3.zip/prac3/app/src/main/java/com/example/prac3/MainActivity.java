package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button prac1,prac2,prac3,prac4,prac5,prac6,prac7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ControlInitialization();
        ButtonClick();
    }

    public void ControlInitialization(){
        prac1=findViewById(R.id.btn1);
        prac2=findViewById(R.id.btn2);
        prac3=findViewById(R.id.btn3);
        prac4=findViewById(R.id.btn4);
        prac7=findViewById(R.id.btn7);
        prac5=findViewById(R.id.btn5);
        prac6=findViewById(R.id.btn6);
    }

    public void ButtonClick(){
        prac1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr1.class);
                startActivity(objIntent);
            }
        });

        prac2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr2.class);
                startActivity(objIntent);
            }
        });

        prac3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr3.class);
                startActivity(objIntent);
            }
        });

        prac4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(), pr4.class);
                startActivity(objIntent);
            }
        });

        prac7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr7.class);
                startActivity(objIntent);
            }
        });

        prac5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr5.class);
                startActivity(objIntent);
            }
        });

        prac6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objIntent=new Intent(getApplicationContext(),pr6.class);
                startActivity(objIntent);
            }
        });
    }
}
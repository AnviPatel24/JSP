package com.example.prac3;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

public class inproduct extends AppCompatActivity {

    Button btsave,btcal,btview;
    EditText e1,e2,e3;

    DatabaseHelper6 dh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inproduct);

        dh=new DatabaseHelper6(inproduct.this,"product",null,1);


        btsave=findViewById(R.id.save);
        btcal=findViewById(R.id.cal);
        btview=findViewById(R.id.vi);

        e1=findViewById(R.id.pname);
        e2=findViewById(R.id.price);
        e3=findViewById(R.id.que);


        btsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pname=e1.getText().toString();
                int price=Integer.parseInt(e2.getText().toString());
                int que=Integer.parseInt(e3.getText().toString());

                long rid=dh.savedata(pname,price,que);

                if(rid>0){
                    Toast.makeText(inproduct.this, "Record is inserted .....", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(inproduct.this, "Record is not  inserted .....", Toast.LENGTH_SHORT).show();
                }




            }
        });

        btcal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int price=Integer.parseInt(e2.getText().toString());
                int que=Integer.parseInt(e3.getText().toString());

                String noti= String.valueOf(price*que);

                Toast.makeText(inproduct.this, "Calculate ="+price*que, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),inproduct.class);

                PendingIntent pendingIntent = PendingIntent.getActivity(getApplicationContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

                // Build the notification
                NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), "CHANNEL_ID")
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("Calculate Amount")
                        .setContentText(noti)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);

                // Create a notification manager
                NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

                // Check if the Android version is Oreo or higher, and create a notification channel if necessary
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    NotificationChannel channel = new NotificationChannel("CHANNEL_ID", "My Channel", NotificationManager.IMPORTANCE_HIGH);
                    channel.setDescription("My channel description");
                    notificationManager.createNotificationChannel(channel);
                }

                // Show the notification
                notificationManager.notify(1, builder.build());

            }
        });

        btview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent=new Intent(getApplicationContext(),viproduct.class);
                startActivity(intent);

            }
        });




    }
}
package com.example.prac3;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

public class viproduct extends AppCompatActivity {

    DatabaseHelper6 dbh6;
    ListView lt;
Button b1;
    ArrayList<String> list;


    String filename="prc6.text";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viproduct);
        dbh6=new DatabaseHelper6(viproduct.this,"product",null,1);
        list=new ArrayList<>();
        lt=findViewById(R.id.vis);

        b1=findViewById(R.id.writef);


        showdata();




    }

    public  void  showdata(){

        Cursor cursor=dbh6.alldate();

        String out="";

        if(cursor!=null){
            Toast.makeText(this, "Cursor is not null", Toast.LENGTH_SHORT).show();

            while (cursor.moveToNext()){

                list.add("Product ID :"+cursor.getString(0)+"\n"+"Product Name :"+cursor.getString(1)+"\n"+"Price :"+cursor.getString(2)+"\n"+"Qty :"+cursor.getString(3)+"\n");

                out+=cursor.getString(0)+"\n"+cursor.getString(1)+"\n"+cursor.getString(2)+"\n"+cursor.getString(3)+"\n";

            }

            ArrayAdapter at=new ArrayAdapter(this, android.R.layout.simple_list_item_1,list);
            lt.setAdapter(at);

            File file=new File(filename);

            try{

                FileOutputStream fos = openFileOutput(filename, MODE_PRIVATE);
                fos.write(out.getBytes());
                fos.close();
                Toast.makeText(getApplicationContext(), "Saved to "+filename, Toast.LENGTH_SHORT).show();
            }
            catch (FileNotFoundException f){

                Toast.makeText(getApplicationContext(), "File is not created ", Toast.LENGTH_SHORT).show();


            } catch (IOException e) {
                e.printStackTrace();
            }


        }
        else{
            Toast.makeText(this, "Cursor is  null", Toast.LENGTH_SHORT).show();
        }

    }

}
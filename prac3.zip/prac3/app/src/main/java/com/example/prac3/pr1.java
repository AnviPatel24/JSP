package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class pr1 extends AppCompatActivity {

    Button btnlog;
    TextView tmail,tpass;
    EditText email,epass;
    CheckBox chkrem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pr1);

        Control();
        ButtonClick();
        SharedPreferences sh=getSharedPreferences("Login",MODE_PRIVATE);
        int j=sh.getInt("autologin",0);
        if(j>0){
            Intent objIntent=new Intent(this,welcome.class);
            startActivity(objIntent);
        }
    }

    public void Control(){
       btnlog=findViewById(R.id.btnlogin);
       tmail=findViewById(R.id.txtmail);
       tpass=findViewById(R.id.txtpass);
       email=findViewById(R.id.etxtmail);
       epass=findViewById(R.id.etxtpass);
       chkrem=findViewById(R.id.chrem);
    }

    public void ButtonClick(){
        btnlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail="20bmiit081@gmail.com";
                String pass="Anvi";
                if(email.getText().toString().equals(mail) && epass.getText().toString().equals(pass)){
                    if(chkrem.isChecked())
                    {
                        SaveLoginDetails(mail,pass);
                        Intent objIntent=new Intent(getApplicationContext(),welcome.class);
                        startActivity(objIntent);
                    }
                    else{
                       // unsave();
                        chkrem.setChecked(false);
                        Intent objIntent=new Intent(getApplicationContext(),welcome.class);
                        startActivity(objIntent);
                    }
                }
                else{
                    Toast.makeText(pr1.this, "Incorrect Email Or Password", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void SaveLoginDetails(String mail,String pass){
        SharedPreferences sh=getSharedPreferences("Login",MODE_PRIVATE);
        SharedPreferences.Editor editor=sh.edit();
        editor.putString("username",mail);
        editor.putString("password",pass);
        editor.putInt("autologin",1);
        editor.commit();
    }

    public void unsave(){
        SharedPreferences sh=getSharedPreferences("Login",MODE_PRIVATE);
        SharedPreferences.Editor editor=sh.edit();
        editor.remove("username");
        editor.remove("password");
        editor.commit();
    }

}
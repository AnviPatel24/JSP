package com.example.prac3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper5 extends SQLiteOpenHelper {
    public DatabaseHelper5(Context context, String dbname, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, dbname, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String create = "CREATE TABLE ITEM(itemid INTEGER PRIMARY KEY AUTOINCREMENT,itemphone varchar(50),itemname varchar(50),itemquan varchar(50))";
        Log.d("table",create);
        db.execSQL(create);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS ITEM");
        onCreate(db);
    }

    public long additem(String phone,String name,String quantity){
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues cv=new ContentValues();
        cv.put("itemphone",phone);
        cv.put("itemname",name);
        cv.put("itemquan",quantity);
        long in=db.insert("ITEM",null,cv);
        return in;
    }

    public Cursor display(){
        SQLiteDatabase db=this.getReadableDatabase();
        Cursor c = db.query("ITEM",null,null,null,null,null,null);
       // Cursor c=db.rawQuery( "select * from ITEM", null );
        return c;
    }
}


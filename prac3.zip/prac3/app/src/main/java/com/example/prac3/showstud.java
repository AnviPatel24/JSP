package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class showstud extends AppCompatActivity {
        ListView lvshow;
        ArrayList<String> Listitem;
    DatabaseHelper7 dbh7;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showstud);
        dbh7=new DatabaseHelper7(showstud.this,"dbpr3",null,1);
        lvshow=findViewById(R.id.showstud);
        Listitem=new ArrayList<>();
        displaydata();

    }

    public void displaydata(){
        Cursor c=dbh7.displaystud();

        if(c!=null){
            Toast.makeText(this, "Cursor Not Null", Toast.LENGTH_SHORT).show();
            while(c.moveToNext()){
                Listitem.add("Student Name: "+c.getString(0)+"\n Student Age: "+c.getString(1)+"\n Student Stream: "+c.getString(2)+"\n Student Year Of Passing: "+c.getString(3)+"\n Student Percentage: "+c.getString(4));

            }
            ArrayAdapter adapter=new ArrayAdapter(this, android.R.layout.simple_list_item_1,Listitem);
            lvshow.setAdapter(adapter);

        }
        else{
            Toast.makeText(this, "Cursor is Null", Toast.LENGTH_SHORT).show();
        }
    }
}
package com.example.prac3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper6 extends SQLiteOpenHelper {
    Context context;
    public DatabaseHelper6(Context context, String dbname, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, dbname, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table product(pid INTEGER PRIMARY KEY AUTOINCREMENT,productn varchar(50),price int,que int)");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists product");
        onCreate(db);

    }

    //save data

    public long savedata(String pname,int price,int que){

        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues c=new ContentValues();
        c.put("productn",pname);
        c.put("price",price);
        c.put("que",que);

        long rid=db.insert("product",null,c);

        return rid;


    }


    public  Cursor alldate(){


        SQLiteDatabase db2=getReadableDatabase();
        Cursor cursor = null;

         cursor = db2.query("product",null,null,null,null,null,null);

        return cursor;
    }
}

package com.example.prac3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class pr3 extends AppCompatActivity {

    EditText txtcont;
    String txtcontent;
    Button btsave,btread;
    TextView  txtview;
    String filename="Filepr3.txt";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pr3);
        ActivityCompat.requestPermissions(pr3.this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},111);
        ControlInitialization();
        ButtonClick();
    }

    public void ControlInitialization(){
        txtcont=findViewById(R.id.econtent);
        btsave=findViewById(R.id.btnsavec);
        txtview=findViewById(R.id.txtviewc);
        btread=findViewById(R.id.btnreadc);
    }

    public void ButtonClick(){
        btread.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileInputStream fis=null;
                try{
                    fis=openFileInput(filename);
                    InputStreamReader isr=new InputStreamReader(fis);
                    BufferedReader bf=new BufferedReader(isr);
                    StringBuffer sb=new StringBuffer();


                    while ((txtcontent=bf.readLine())!=null){
                        sb.append(txtcontent);
                    }
                    txtview.setText(sb.toString());
                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });

        btsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String word=txtcont.getText().toString();

                File file=new File(filename);

                try{
                    StringBuffer sb=new StringBuffer();
                    FileOutputStream fos = openFileOutput(filename, Context.MODE_PRIVATE);
                    fos.write("\n".getBytes());
                    fos.write(word.getBytes());
                    fos.close();
                    Toast.makeText(pr3.this, "Saved to "+filename, Toast.LENGTH_SHORT).show();
                }
                catch (IOException f){

                    Toast.makeText(pr3.this, "File is not created ", Toast.LENGTH_SHORT).show();
                }



            }
        });
    }
}
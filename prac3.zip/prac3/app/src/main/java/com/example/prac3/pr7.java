package com.example.prac3;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class pr7 extends AppCompatActivity {
        Button btnel,btnrate,btndata;
        DatabaseHelper7 dbh7;
        long execute;
        EditText ename,eage,eyear,eper;
        RadioGroup rgstream;
        RadioButton rdbsci,rdbcom;
        TextView txtshowrate;
        float ratingcount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pr7);
        dbh7=new DatabaseHelper7(pr7.this,"dbpr3",null,1);

        ControlInitialization();
        ButtonClick();
    }

    public void ControlInitialization(){
        btnrate=findViewById(R.id.btnrate);
        btnel=findViewById(R.id.btnshowel);
        ename=findViewById(R.id.txtname);
        eage=findViewById(R.id.txtage);
        eyear=findViewById(R.id.txtyear);
        eper=findViewById(R.id.txtper);
        rgstream=findViewById(R.id.rgstream);
        rdbsci=findViewById(R.id.rdbsci);
        rdbcom=findViewById(R.id.rdbcom);
        txtshowrate=findViewById(R.id.txtshowrate);
        btndata=findViewById(R.id.btnshowstud);
    }

    public void ButtonClick(){
        btnrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showrate();
            }
        });

        btnel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int percent=Integer.parseInt(eper.getText().toString());
                if(rdbsci.isChecked())
                {
                    if(percent>=55 ){
                        String stream=rdbsci.getText().toString();
                        String name=ename.getText().toString();
                        String age=eage.getText().toString();
                        String year=eyear.getText().toString();
                        String per=eper.getText().toString();
                       execute= dbh7.addstudent(name,age,stream,year,per);
                       if(execute>0){
                           Toast.makeText(pr7.this, "Record Inserted Successfully For Science Student", Toast.LENGTH_SHORT).show();
                       }
                    }
                    else{

                        Toast.makeText(pr7.this, "Not Eligible for Admission from Science BAckground", Toast.LENGTH_LONG).show();
                    }
                }
                else if(rdbcom.isChecked())
                {
                    if(percent>=60 ){
                        String stream=rdbcom.getText().toString();
                        String name=ename.getText().toString();
                        String age=eage.getText().toString();
                        String year=eyear.getText().toString();
                        String per=eper.getText().toString();
                        execute=dbh7.addstudent(name,age,stream,year,per);
                        if(execute>0){
                            Toast.makeText(pr7.this, "Record Inserted Successfully For Commerce Student", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else{
                        Toast.makeText(pr7.this, "Not Eligible for Admission from Commerce BAckground", Toast.LENGTH_LONG).show();
                    }
                }

            }
        });

        btndata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent objintent=new Intent(getApplicationContext(),showstud.class);
                startActivity(objintent);
            }
        });
    }

    private void showrate() {
        LayoutInflater layoutInflater=LayoutInflater.from(this);
        View v=layoutInflater.inflate(R.layout.rating,null);
        RatingBar rb=v.findViewById(R.id.rate);

        rb.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                ratingcount=rating;

            }
        });
        AlertDialog.Builder ad=new AlertDialog.Builder(this).setView(v);
        ad.setMessage("Rate This App");
        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                    txtshowrate.setText("Total Rating : "+ratingcount);
            }
        });
        ad.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        ad.create();
        ad.show();
    }


}